#ifndef VERSION_H
#define VERSION_H

/* CMake fills in the variables in version.h.in to make version.h included by OpenBR. */

#define COMPANY_NAME         "OpenBiometrics"
#define PRODUCT_NAME         "OpenBR"
#define PRODUCT_DESCRIPTION  "Open Source Biometric Recognition"
#define PRODUCT_VERSION      "1.1.0"
#define PRODUCT_VERSION_MAJOR 1
#define PRODUCT_VERSION_MINOR 1
#define PRODUCT_VERSION_PATCH 0
#define PRODUCT_VERSION_BIN   1,1,0,0
#define LEGAL_COPYRIGHT       "Copyright (c) 2013 OpenBiometrics. All rights reserved."

#endif // VERSION_H
