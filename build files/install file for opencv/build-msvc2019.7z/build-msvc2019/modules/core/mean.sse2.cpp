
#include "C:/opencv/sources/modules/core/src/precomp.hpp"
#include "C:/opencv/sources/modules/core/src/mean.simd.hpp"
