
#include "C:/opencv/sources/modules/core/src/precomp.hpp"
#include "C:/opencv/sources/modules/core/src/stat.simd.hpp"
