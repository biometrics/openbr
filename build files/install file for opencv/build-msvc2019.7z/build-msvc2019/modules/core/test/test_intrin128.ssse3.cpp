
#include "C:/opencv/sources/modules/core/test/test_precomp.hpp"
#include "C:/opencv/sources/modules/core/test/test_intrin128.simd.hpp"
