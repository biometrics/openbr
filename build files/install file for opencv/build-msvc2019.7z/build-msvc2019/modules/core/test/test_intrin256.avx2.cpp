
#include "C:/opencv/sources/modules/core/test/test_precomp.hpp"
#include "C:/opencv/sources/modules/core/test/test_intrin256.simd.hpp"
