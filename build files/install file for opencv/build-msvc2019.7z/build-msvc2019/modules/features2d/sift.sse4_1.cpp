
#include "C:/opencv/sources/modules/features2d/src/precomp.hpp"
#include "C:/opencv/sources/modules/features2d/src/sift.simd.hpp"
