
#define OPENCV_INSTALL_PREFIX "C:/opencv/sources/build-msvc2019/install"

#define OPENCV_DATA_INSTALL_PATH "etc"

#define OPENCV_BUILD_DIR "C:/opencv/sources/build-msvc2019"

#define OPENCV_DATA_BUILD_DIR_SEARCH_PATHS \
    "..//"

#define OPENCV_INSTALL_DATA_DIR_RELATIVE "../../../etc"
