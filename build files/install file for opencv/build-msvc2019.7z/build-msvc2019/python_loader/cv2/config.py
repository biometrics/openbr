import os

BINARIES_PATHS = [
    'C:/opencv/sources/build-msvc2019/bin'
] + BINARIES_PATHS
